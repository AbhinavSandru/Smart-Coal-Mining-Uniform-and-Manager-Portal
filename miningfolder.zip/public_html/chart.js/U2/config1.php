<!doctype html public "-//w3c//dtd html 3.2//en">
<html>
<head>
<title>plus2net.com : Line chart using data from MySQL table</title>
</head>
<body>
<?php
// Database connection
$host = "localhost";
$database = "id19581971_sen";       // Change your database name
$username = "id19581971_coal";     // Your database user id 
$password = "U1user1@1234";         // Your password

//error_reporting(0);// With this no error reporting will be there
///// Do not Edit below //////
$connection=mysqli_connect($host,$username,$password,$database);
if (!$connection) {
    echo "Error: Unable to connect to MySQL.<br>";
    echo "<br>Debugging errno: " . mysqli_connect_errno();
    echo "<br>Debugging error: " . mysqli_connect_error();
    exit;
}

if($stmt = $connection->query("SELECT * FROM u2")){

$jsonArray = Array(); // create PHP array
if ($stmt->num_rows > 0) {
while($row = $stmt->fetch_assoc()) {
  $jsonArrayItem = array();
  $jsonArrayItem['temperature'] = (int)($row['temp']);
  $jsonArrayItem['humidity'] = (int)($row['humidity']);
  $jsonArrayItem['gas'] = (int)($row['gas']);
  $jsonArrayItem['light'] = (int)($row['light']);
  $jsonArrayItem['sound'] = (int)($row['sound']);
  $jsonArrayItem['timestamp'] = $row['time&date'];

  //append the above created object into the main array.
  array_push($jsonArray, $jsonArrayItem);
}
}
while ($row = $stmt->fetch_row()) {
   $php_data_array[] = $row; // Adding to array
   }
}else{
echo $connection->error;
}

//print_r( $php_data_array);
// You can display the json_encode output here. 
//echo json_encode($php_data_array); 

// Transfor PHP array to JavaScript two dimensional array 
$json = json_encode($jsonArray);
if (file_put_contents("data1.json", $json))
    echo "JSON file created successfully...";
else 
    echo "Oops! Error creating json file...";


?>


